#!/bin/bash

set -e
run_cmd="dotnet out/SecureBank.dll --server.urls http://*:80"

echo "Going to sleep for 5 seconds waiting for SQL server run"
sleep 5

>&2 echo "SQL Server is up - executing command"
exec $run_cmd
