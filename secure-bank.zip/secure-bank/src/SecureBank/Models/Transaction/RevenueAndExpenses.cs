﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SecureBank.Models.Transaction
{
    public class RevenueAndExpenses
    {
        public double Revenue { get; set; }
        public double Expenses { get; set; }
    }
}
