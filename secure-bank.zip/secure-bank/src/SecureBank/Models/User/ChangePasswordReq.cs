using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace SecureBank.Models.User
{
    public class ChangePasswordReq
    {
        public string oldPassword { get; set; }

        [Required(ErrorMessage = "New password is required.")]
        public string newPassword { get; set; }
    }
}
