﻿using SecureBank.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SecureBank.Helpers.Authorization.Attributes;
using SecureBank.Interfaces;
using SecureBank.Models.Store;
using SecureBank.Models.AdminStoreUploadItems;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;
using System.Runtime.Serialization;
using System.Diagnostics;

namespace SecureBank.Controllers.Api
{
    [AuthorizeAdmin(AuthorizeAttributeTypes.Api)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public class AdminStoreController : ApiBaseController
    {
        private readonly IAdminStoreBL _adminStoreBL;

        public AdminStoreController(IAdminStoreBL adminStoreBL)
        {
            _adminStoreBL = adminStoreBL;
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<List<PurcahseHistoryItemResp>>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllPurchases()
        {
            List<PurcahseHistoryItemResp> resp = await _adminStoreBL.GetAllPurchases();
            if (resp == null)
            {
                return BadRequest();
            }

            return Ok(resp);
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<StoreItem>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetStoreItems()
        {
            DataTableResp<StoreItem> dataTableResp = await _adminStoreBL.GetStoreItems();
            if (dataTableResp == null)
            {
                return BadRequest();
            }

            return Ok(dataTableResp);
        }

        [HttpPost]
        [ProducesResponseType(typeof(EmptyResult), StatusCodes.Status200OK)]
        public async Task<IActionResult> Create([FromBody]StoreItem storeItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            bool result = await _adminStoreBL.CreateStoreItem(storeItem);
            if (!result)
            {
                return BadRequest();
            }

            return Ok(new EmptyResult());
        }

        [HttpGet("{id}")]
        [ProducesResponseType(typeof(StoreItem), StatusCodes.Status200OK)]
        public async Task<IActionResult> Get([FromRoute] int id)
        {
            StoreItem storeItem = await _adminStoreBL.GetStoreItem(id);
            if (storeItem == null)
            {
                return BadRequest();
            }

            return Ok(storeItem);
        }

        [HttpPost("{id}")]
        [ProducesResponseType(typeof(StoreItem), StatusCodes.Status200OK)]
        public async Task<IActionResult> Edit([FromRoute] int id, [FromBody] StoreItem storeItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            StoreItem editedStoreItem = await _adminStoreBL.EditStoreItem(id, storeItem);
            if (editedStoreItem == null)
            {
                return BadRequest();
            }

            return Ok(editedStoreItem);
        }

        [HttpPost]
        [ProducesResponseType(typeof(EmptyResult), StatusCodes.Status200OK)]
        public async Task<IActionResult> DeleteStoreItem([FromBody] StoreItem storeItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            bool deleteResult = await _adminStoreBL.DeleteStoreItem(storeItem);
            if (!deleteResult)
            {
                return BadRequest();
            }

            return Ok(new EmptyResult());
        }

        /// <summary>
        /// Downloads the store items as a base64-encoded binary serialized string.
        /// </summary>
        [HttpGet]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        public async Task<IActionResult> DownloadStoreItems()
        {
            // items are extracted from StoreAPI
            DataTableResp<StoreItem> dataTableResp = await _adminStoreBL.GetStoreItems();
            if (dataTableResp == null) { return BadRequest(); }

            try {
                string json = JsonConvert.SerializeObject(dataTableResp);
                return Ok(json);
            } catch (Exception ex) {
                return BadRequest($"Serialization failed: {ex.Message}");
            }  

        }

        /// <summary>
        /// Deserializes a base64 string into a DataTableResp of StoreItem.
        /// </summary>
        [HttpPost]
        [ProducesResponseType(typeof(DataTableResp<StoreItem>), StatusCodes.Status200OK)]
        public async Task<IActionResult> UploadStoreItems()
        {
            // decode base64 and deserialize data
            using (var reader = new StreamReader(Request.Body)) {
                string jsonData = await reader.ReadToEndAsync();
                
                try {
                    var obj = JsonConvert.DeserializeObject<object>(jsonData, new JsonSerializerSettings
                    {
                        TypeNameHandling = TypeNameHandling.All
                    });
                    return Ok(obj);
                } catch (Exception ex) {
                    return BadRequest($"Deserialization failed: {ex.Message}");
                }                
            }
        }
    }
    
}
