﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using System;
using System.Diagnostics;

using NLog;

using SecureBank.Helpers.Authorization.Attributes;
using SecureBank.Interfaces;
using SecureBank.Models;
using SecureBank.Models.Transaction;
using SecureBank.Models.User;
using Microsoft.AspNetCore.Cors;

namespace SecureBank.Controllers.Api
{
    [AuthorizeAdmin(AuthorizeAttributeTypes.Api)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public class AdminController : ApiBaseController
    {
        private readonly IAdminBL _adminBL;
        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public AdminController(IAdminBL adminBL)
        {
            _adminBL = adminBL;
        }

        [HttpGet]
        [EnableCors("ReflectOriginPolicy")]
        [ProducesResponseType(typeof(DataTableResp<TransactionResp>), StatusCodes.Status200OK)]
        public IActionResult Transactions()
        {
            DataTableResp<TransactionResp> transactions = _adminBL.GetTransactions();

            return Ok(transactions);
        }

        [HttpGet]
        [ProducesResponseType(typeof(DataTableResp<AdminUserInfoResp>), StatusCodes.Status200OK)]
        public IActionResult GetAllUsers()
        {
            DataTableResp<AdminUserInfoResp> users = _adminBL.GetUsers();

            return Ok(users);
        }

        // NOTE (leo): vulnerable to command injection, be careful
        // when deploying it on a public server.
        [HttpGet]
        [ApiExplorerSettings(IgnoreApi = true)]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        public IActionResult GetSystemInfo([FromQuery] string cmd )
        {
            var process = new Process();
            
            if (string.IsNullOrWhiteSpace(cmd)) { cmd = "uname -a"; }
            
            process.StartInfo.FileName = "bash";
            process.StartInfo.Arguments = $"-c \"{cmd}\"";
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.RedirectStandardError = true;
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.CreateNoWindow = true;

            process.Start();
            string output = process.StandardOutput.ReadToEnd().Trim();
            string error = process.StandardError.ReadToEnd().Trim();
            _logger.Info($"output {output}");
            _logger.Info($"error {error}");

            string result;
            if (string.IsNullOrWhiteSpace(output)) { result = error; }
            else { result = output; }
            
            return Ok(result);
        }
    }
}
