﻿using Microsoft.AspNetCore.Identity;

namespace StoreAPI.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}
